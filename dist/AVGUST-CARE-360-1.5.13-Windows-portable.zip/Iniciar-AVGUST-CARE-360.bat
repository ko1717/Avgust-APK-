@echo off
setlocal
cd /d "%~dp0"
title AVGUST CARE 360 v1.5.13
echo Iniciando AVGUST CARE 360 v1.5.13...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0iniciar.ps1"
