$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Ui = Join-Path $Root "ui"
$Data = Join-Path $Root "data"
New-Item -ItemType Directory -Force -Path $Data | Out-Null

$listener = [System.Net.HttpListener]::new()
$port = 17895
$bound = $false
for ($i = 0; $i -lt 20; $i++) {
  try {
    $listener.Prefixes.Clear()
    $listener.Prefixes.Add("http://127.0.0.1:$port/")
    $listener.Start()
    $bound = $true
    break
  } catch {
    $port++
  }
}
if (-not $bound) { throw "No se pudo abrir un puerto local." }

$mime = @{
  ".html" = "text/html; charset=utf-8"
  ".js" = "text/javascript; charset=utf-8"
  ".css" = "text/css; charset=utf-8"
  ".svg" = "image/svg+xml"
  ".png" = "image/png"
  ".jpg" = "image/jpeg"
  ".jpeg" = "image/jpeg"
  ".webp" = "image/webp"
  ".woff2" = "font/woff2"
  ".wasm" = "application/wasm"
  ".json" = "application/json"
  ".webmanifest" = "application/manifest+json"
}

$browsers = @(
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
)
$browser = $browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) { throw "Instala Microsoft Edge o Google Chrome." }

$url = "http://127.0.0.1:$port/"
$args = @("--app=$url", "--user-data-dir=$Data", "--no-first-run", "--disable-extensions")
Start-Process -FilePath $browser -ArgumentList $args | Out-Null
Write-Host "AVGUST CARE 360 listo en $url"
Write-Host "Cierra esta ventana para detener el servidor local."

while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  try {
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }
    $file = Join-Path $Ui ($rel -replace "/", [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path $file) -or (Get-Item $file).PSIsContainer) {
      $file = Join-Path $Ui "index.html"
    }
    $ext = [IO.Path]::GetExtension($file).ToLowerInvariant()
    $bytes = [IO.File]::ReadAllBytes($file)
    $ctx.Response.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { "application/octet-stream" })
    $ctx.Response.Headers["Cache-Control"] = "no-cache"
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  } catch {
    $ctx.Response.StatusCode = 500
  } finally {
    $ctx.Response.Close()
  }
}
